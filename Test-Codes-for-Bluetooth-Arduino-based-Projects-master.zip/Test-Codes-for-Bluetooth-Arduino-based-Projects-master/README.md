# Test-Codes-for-Bluetooth-Arduino-based-Projects

There are 2 codes:
1. To send data from Arduino Automation App to Arduino board 
2. To send data from Arduino board to Arduino Automation App 

You can download the Arduino Automation App from this link: https://play.google.com/store/apps/details?id=com.himanshu.ArduinoAutomation
